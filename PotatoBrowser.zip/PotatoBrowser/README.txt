WARNING: You will need python installed on the system for this to work!

WARNING: By running this file you agree to not share files or distribute this to anyone else. By sharing this file you agree to pay $10 to the creator of this file.

To use the browser click the directory bar (where it says what folder you are in) then type 'cmd'

In Command Prompt type the following:
'pip install PyQt5'
'pip install PyQtWebEngine'

Then run PotatoBrowser.py